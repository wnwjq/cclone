head의 title은 인터넷에서 검색했을 때 검색 결과 창에 뜨게 된다.  
2-6  

- meta태그는 부가적인 정보. 페이지 이름 밑에 작은 글씨로 설명 적어져있는 부분. description.  
- meta charset=인코딩 지정.  
- link rel="shortcut icon":탭 부분에 숏컷 이미지 생성해줌. sizes는 없어도 되긴 함.  
- meta property="og:  
오픈그래프 Open Graph  
콘텐츠의 요약내용이 SNS에 게시되는데 최적화된 데이터를 가지고 갈 수 있도록 설정하는 것  
어떤 HTML 문서의 메타정보를 쉽게 표시하기 위해서
메타정보에 해당하는 제목, 설명, 문서의 타입, 대표 URL 등 다양한 요소들에 대해서 사람들이 통일해서 쓸 수 있도록 정의해놓은 프로토콜.  

<meta property="og:type" content="website">  
<meta property="og:title" content="페이지 제목">  
<meta property="og:description" content="페이지 설명">  
<meta property="og:image" content="http://www.mysite.com/myimage.jpg">  
<meta property="og:url" content="http://www.mysite.com">  

- meta name="소셜미디어: "  
소셜미디어에서 공유될 정보를 정할 수 있음

<meta name="twitter:card" content="summary">  
<meta name="twitter:title" content="페이지 제목">  
<meta name="twitter:description" content="페이지 설명">  
<meta name="twitter:image" content="http://www.mysite.com/article/article1.html">  
<meta name="twitter:domain" content="사이트 명">  


2-7  
- html, css, js 관련해 구글에서 검색할 때 'mdn'을 붙여서 검색해라. =>mozilla developer network.  
w3schools는 쓰지 마라.

- mark 태크:형광펜.  

-sub:아래 첨자/sup:윗 첨자