$(document).ready(function(){
   $('.tasks').click(function(){
     if($('.tasks').hasClass('tasks')){
         $('.tasks').css('visibility', 'hidden');
        $('.tasks').addClass('close').removeClass('tasks');
        $('.tasks-board').css('visibility', 'visible');

        $('.close').css('visibility', 'visible');

     }else if($('.close').hasClass('close')){
        $('.close').addClass('tasks').removeClass('close');  
        $('.tasks-board').css('visibility', 'hidden');


        
     }
   });
 });